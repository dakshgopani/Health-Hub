import 'package:flutter/material.dart';
import 'package:mad_practice_one/screens/medication_page.dart';
import 'package:mad_practice_one/screens/quiz_screen.dart';

import 'medicine_recommender.dart';

class MedicinePage extends StatefulWidget {
  const MedicinePage({super.key});

  @override
  _MedicinePageState createState() => _MedicinePageState();
}

class _MedicinePageState extends State<MedicinePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),

            // 🏥 Medicine Scanner Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Medicine\nScanner",
                    style: TextStyle(
                      color: Color(0xFF432C81),
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Raleway',
                    ),
                  ),
                  Image.asset(
                    'assets/images/home_page/medicine_reminder.png', // Ensure this asset exists
                    width: 100,
                    height: 100,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Medicine-related Options
            _buildOption("Scan a Medicine", () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MedicineScannerPage(),
                ),
              );
            }),

            // Medicine-related Options
            _buildOption("Medicine Recommender", () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MedicineRecommender(),
                ),
              );
            }),

            // Medicine-related Options
            _buildOption("MediMaster Quiz", () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => QuizScreen(),
                ),
              );
            }),

          ],
        ),
      ),
    );
  }

  /// ✅ Reusable Option Widget
  Widget _buildOption(String title, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
        decoration: BoxDecoration(
          color: Colors.deepPurple[50],
          borderRadius: BorderRadius.circular(15),
          boxShadow: const [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 4,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: InkWell(
          onTap: onTap, // Action when clicked
          borderRadius: BorderRadius.circular(15),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    color: Color(0xFF432C81),
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Raleway',
                  ),
                ),
              ),
              IconButton(
                icon: Image.asset(
                  'assets/icons/arrow_next_page.png', // Ensure this asset exists
                  width: 24,
                  height: 24,
                ),
                onPressed: onTap,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
